var manager = new THREE.LoadingManager();

manager.onProgress = function ( item, loaded, total ) {
  //window.update_preloader(100*loaded/total);
};

manager.onLoad = function () {
  document.getElementById('preloader').style.display = "none";
};

/*
(function(){

  var angle = 0;
  var circle = document.getElementById("arc");
  window.update_preloader = function(pct) {
    
    var angle = 0;
    var radius = 120;     

    var target_angle = 360 * pct / 100;

    while (angle < target_angle){
      if (angle > 720) {
        angle -= 720;
      }
      radians= (angle/180) * Math.PI - Math.PI/2;
      var x = Math.cos(radians) * radius;
      var y = Math.sin(radians) * radius;
      var e = circle.getAttribute("d");

      if (angle > 360) {
        var p = e.split(" ");
        p.shift();
        var d = p.join(" ").replace("L", "M");
      } else {
        if(angle==0) {
            var d = e+ " M"+x.toFixed(4) + "," + y.toFixed(4);
        }
        else {
            var d = e+ " L"+x.toFixed(4) + "," + y.toFixed(4);
        }  
      }
      circle.setAttribute("d", d);
      var inner = document.getElementById('inner');
      inner.setAttribute("transform", "rotate("+angle+")");
      angle += 6;
    }
  }

})();

*/

var onObjProgress = function() {};
var onObjError = function() {};

var textureLoader = new THREE.TextureLoader();

function setup_fireflies() {
  numPointLights = 20;
  for (var i=0;i<numPointLights;i++) {
    pointLights.push(pl(Math.floor(Math.random*800-400, Math.random*800-400, Math.random*800-400, 0.1, 0xffff00)));
  }
}