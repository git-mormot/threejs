
var bg_loop = new Audio('nissan/sounds/100616_GESE_Loopable.mp3');
bg_loop.addEventListener('ended', function() {
    this.currentTime = 0;
    this.play();
}, false);
bg_loop.play(); //10.18.16 disable sound

var canvas = document.querySelector('#eq'),
    ctx = canvas.getContext('2d');

ctx.fillStyle = 'white';
// here we create our chain
var audioContext = new AudioContext(),
    source = audioContext.createMediaElementSource(bg_loop),
    analyser = audioContext.createAnalyser();

source.connect(analyser);
analyser.connect(audioContext.destination);

var music_bars = [
  0,0,0,0,0,0
];

setInterval(function(){
  var freqData = new Uint8Array(analyser.frequencyBinCount);

      analyser.getByteFrequencyData(freqData);
      
      width = 50;
      height = 50;

      ctx.clearRect(0, 0, width, height);
      var num_samples = freqData.length / 8;
      var step = 3;

      var ii = 0;
      for (var i = 0; ii < 7; i += step ) {
        var bar_height = 0;
        for (var j = i; j < i + step; j++) {
          bar_height += freqData[j];
        }

        // animate the paint to music
        music_bars[ii] = bar_height;

        step += 2;
        ii++;
        ctx.fillRect(ii * 4, 50, 2, -1 * bar_height / step / 6);
      }
 }, 33);

var eq_wrap = document.getElementById("eq_wrap");
var play_el = document.getElementById("play_toggle");
eq_wrap.addEventListener('click', function() {
  if (bg_loop.paused){
    bg_loop.play();
    play_el.className = "";
  } else {
    bg_loop.pause();
    play_el.className = "playing";
  }
});