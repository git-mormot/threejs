
function add_bridge() {
  
  /*
  var geometry = new THREE.BoxGeometry( 200000,100,2000);
  for (var i=0;i<21;i++) {
    var g = new THREE.BoxGeometry( 300,10000,2000);
    var post = new THREE.Mesh(g, material)
    post.position.x = -100000 + i * 10000;
    post.position.y = -5000
    post.updateMatrix();
    geometry.merge(post.geometry, post.matrix);
  }

  var texture = new THREE.TextureLoader().load( "textures/concrete.jpg" );
  texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set( 1,5 );

  material = new THREE.MeshLambertMaterial( { color: 0x222222, map: texture, envMap: envCube, combine: THREE.MixOperation, reflectivity: 0.3} );

  var bridge = new THREE.Mesh( geometry, material );
  bridge.position.z = -6000
  bridge.position.y = 5000
  bridge.rotateY(-0.58)
  
  scene.add( bridge );
  */




  var texture = new THREE.Texture();

  var onProgress = function ( xhr ) {
    if ( xhr.lengthComputable ) {
      var percentComplete = xhr.loaded / xhr.total * 100;
      console.log( Math.round(percentComplete, 2) + '% downloaded' );
    }
  };

  var onError = function ( xhr ) {
  };


  var loader = new THREE.ImageLoader( manager );
  loader.load( 'obj/bridge/newtexture3.jpg', function ( image ) {

    texture.image = image;
    texture.needsUpdate = true;

  } );

  // model

  var bridge_angle = 3.6;

  var loader = new THREE.OBJLoader( manager );
  loader.load( 'obj/bridge/bridge_nolights.obj', function ( object ) {
    object.traverse( function ( child ) {
      if ( child instanceof THREE.Mesh ) {
        child.material.map = texture;
      }
    } );

    object.scale.set(10,10,10);
    object.position.y = 0;
    object.position.x = -27000;
    object.position.z = -42000;
    object.rotateY(bridge_angle);
    scene.add( object );

  }, onProgress, onError );


  var loader = new THREE.OBJLoader( manager );
  loader.load( 'obj/bridge/base.obj', function ( object ) {

    object.traverse( function ( child ) {
      if ( child instanceof THREE.Mesh ) {
        child.material.map = texture;
      }
    } );

    object.scale.set(10,10,10);
    for (var i=0; i< 6; i++){
      var o = object.clone();
      var piece_length = 2270;
      o.rotateY(bridge_angle);

      o.position.x = -8900 + i * Math.sin(bridge_angle)*piece_length;
      o.position.z = -5130 + i * Math.cos(bridge_angle)*piece_length;
      o.position.y = 0; //- Math.abs(i-10) * 100
      o.updateMatrix();
      scene.add(o);
    }

  }, onProgress, onError );  

}
