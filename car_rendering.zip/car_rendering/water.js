
var water_mesh, water;

var spheres = [];
function add_water(){


        var geometry = new THREE.SphereBufferGeometry( 100, 32, 16 );

        var material = new THREE.MeshBasicMaterial( { color: 0xffffff, envMap: refCube, refractionRatio: 0.99, fog:false } );

        for ( var i = 0; i < 500; i ++ ) {

          var mesh = new THREE.Mesh( geometry, material );

          mesh.position.x = Math.random() * 10000 - 5000;
          mesh.position.y = Math.random() * 10000 - 5000;
          mesh.position.z = Math.random() * 10000 - 5000;

          mesh.scale.x = mesh.scale.y = mesh.scale.z = Math.random() * 3 + 1;

          scene.add( mesh );

          spheres.push( mesh );

        }
        return

        //water = new THREE.BoxGeometry( 800, 20000, 800, worldWidth - 1, worldDepth - 1 , 1);
        water = new THREE.BoxGeometry( 800, 800, 800, worldWidth - 1, worldDepth - 1 , 1);
        //water.rotateX( - Math.PI / 3 );

        for ( var i = 0, l = water.vertices.length; i < l; i ++ ) {

          //water.vertices[ i ].y = 35 * Math.sin( i / 2 );

        }

        var texture = new THREE.TextureLoader().load( "textures/water.jpg" );
        texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
        texture.repeat.set(1 , 10 );

        //material = new THREE.MeshBasicMaterial( { color: 0x666666, map: texture, fog:false } );
        var material = new THREE.MeshBasicMaterial( { color: 0xffffff, envMap: refCube, refractionRatio: 1, fog:false } );

        water_mesh = new THREE.Mesh( water, material );
        /*
        water_mesh.rotateX( -0.035);
        water_mesh.position.x = 10000;
        water_mesh.position.y = 525;
        water_mesh.position.z = 0;
        water_mesh.rotateZ( Math.PI/2);
        */

        scene.add( water_mesh );

  return

  var geometry = new THREE.BoxGeometry( 100, 100, 100, 10, 10, 10 );

  var material = new THREE.MeshBasicMaterial( { color: 0xffffff, envMap: refCube, refractionRatio: 1 } );

  for ( var i = 0; i < 500; i ++ ) {

    var mesh = new THREE.Mesh( geometry, material );

    mesh.position.x = Math.random() * 10000 - 5000;
    mesh.position.y = 0;
    mesh.position.z = Math.random() * 10000 - 5000;

    mesh.scale.x = mesh.scale.y = mesh.scale.z = Math.random() * 3 + 1;

    scene.add( mesh );
    spheres.push(mesh);
  }
}