if ( ! Detector.webgl ) Detector.addGetWebGLMessage();

var RENDER_TARGET_WIDTH = 500;
var RENDER_TARGET_HEIGHT = 700;

var renderer_left;
var renderer_right;

var el_render_left;
var el_render_right;

var camera;
var scene;
var scene_right;
var controls;
var controls_right;

var stewartPB;

var stats;

function OneTimeSceneInit() {
	container = document.createElement( 'div' );
	document.body.appendChild( container );

	el_render_left  = document.getElementById("render-left");
	el_render_right = document.getElementById("render-right");

	el_render_left.style.width  = RENDER_TARGET_WIDTH + "px";
	el_render_left.style.height = RENDER_TARGET_HEIGHT + "px";

	el_render_right.style.width  = RENDER_TARGET_WIDTH + "px";
	el_render_right.style.height = RENDER_TARGET_HEIGHT + "px";

	camera = new THREE.PerspectiveCamera( 45, RENDER_TARGET_WIDTH / RENDER_TARGET_HEIGHT, 0.1, 2000 );

	scene = new THREE.Scene();
	scene.background = new THREE.Color( 0x558c89 );
	scene_right = new THREE.Scene();
	scene_right.background = new THREE.Color( 0x558c89 );

	var manager = new THREE.LoadingManager();
	manager.onProgress = function( item, loaded, total ) {
		console.log( item, loaded, total );
	};

	var loader = new THREE.OBJLoader( manager );

	stewartPB = new StewartPlatformBase( loader, scene, scene_right );
	stewartPB.loadResourceAndSetup();

	renderer_left = new THREE.WebGLRenderer();
	renderer_left.setPixelRatio( window.devicePixelRatio );
	renderer_left.setSize( RENDER_TARGET_WIDTH, RENDER_TARGET_HEIGHT );
	renderer_left.setClearColor( 0x000000 );
	el_render_left.appendChild( renderer_left.domElement );

	renderer_right = new THREE.WebGLRenderer();
	renderer_right.setPixelRatio( window.devicePixelRatio );
	renderer_right.setSize( RENDER_TARGET_WIDTH, RENDER_TARGET_HEIGHT );
	renderer_right.setClearColor( 0x000000 );
	el_render_right.appendChild( renderer_right.domElement );

	// controls, camera
	// controls = new THREE.OrbitControls( camera, renderer_left.domElement );
	// controls.target.set( 0, 0, 0 );
	// controls.enablePan = false;
	// controls.rotateSpeed = 0.05;
	// controls.enableDamping = true;
	// controls.dampingFactor = 0.1;
	// controls.update();

	controls_right = new THREE.OrbitControls( camera, renderer_right.domElement );
	controls_right.target.set( 0, 0, 0 );
	camera.position.set( 0, 0, -20 );
	controls_right.update();


	// stats = new Stats();
	// document.getElementById( "stats" ).appendChild( stats.dom );
	// document.getElementById( "stats" ).firstChild.style.position = "initial";
	// document.getElementById( "stats" ).firstChild.style.top = "initial";
	// document.getElementById( "stats" ).firstChild.style.left = "initial";
	onWindowResize();
	animate();
}

function onWindowResize() {
	camera.aspect = RENDER_TARGET_WIDTH / RENDER_TARGET_HEIGHT;
	camera.updateProjectionMatrix();
	renderer_left.setSize( RENDER_TARGET_WIDTH, RENDER_TARGET_HEIGHT );
	renderer_right.setSize( RENDER_TARGET_WIDTH, RENDER_TARGET_HEIGHT );
}

function animate() {
	requestAnimationFrame( animate );
	render();
	// stats.update();
}

function render() {
	renderer_left.render( scene, camera );
	renderer_right.render( scene_right, camera );
}

window.addEventListener( 'resize', onWindowResize, false );

// document.getElementById( 'btn-update' ).addEventListener( 'click', function () {
// 	stewartPB.updateState( {
// 		platform_pos_orient: [
// 			document.getElementById( 'platform-x' ).value,
// 			document.getElementById( 'platform-y' ).value,
// 			document.getElementById( 'platform-z' ).value,

// 			document.getElementById( 'platform-a' ).value,
// 			document.getElementById( 'platform-b' ).value,
// 			document.getElementById( 'platform-c' ).value
// 		],
// 		platform_pos_orient_right: [
// 			document.getElementById( 'platform-x-right' ).value,
// 			document.getElementById( 'platform-y-right' ).value,
// 			document.getElementById( 'platform-z-right' ).value,

// 			document.getElementById( 'platform-a-right' ).value,
// 			document.getElementById( 'platform-b-right' ).value,
// 			document.getElementById( 'platform-c-right' ).value
// 		],
// 		strut_connection: [
// 			[0, 23],
// 			[1, 5 ],
// 			[8, 6 ],
// 			[9, 12],
// 			[16,13],
// 			[17,22]
// 		]
// 	} );

// });

OneTimeSceneInit();