var Bone = function () {};

Bone.prototype.setUp = function ( bone_pieces, baseRing, platformRing ) {
	
	this.bone_geo     = new THREE.Geometry().fromBufferGeometry( bone_pieces.geometry );
	this.baseRing     = baseRing;
	this.platformRing = platformRing;

	this.upperBoneMesh = new THREE.Mesh();
	this.lowerBoneMesh = new THREE.Mesh();
	this.cutPlane = new THREE.Plane();

	var loader = new THREE.TextureLoader();
	var texBone = loader.load( "/stewartplatform/asset/bone2.jpg" );
	var boneMaterial =  new THREE.MeshPhongMaterial({
		side : THREE.DoubleSide,
	    map : texBone,
	    side : THREE.DoubleSide,
	    shininess : 0,
	    bumpMap : texBone,
	    bumpScale : 1,
	    color : "#ffffff"
	});

	this.upperBoneMesh.material = boneMaterial;
	this.lowerBoneMesh.material = boneMaterial;
	// this.upperBoneMesh.scale.set( 0.25, 0.25, 0.25 );
	// this.lowerBoneMesh.scale.set( 0.25, 0.25, 0.25 );

	this.bone_geo.translate( 0.0, -2.0, 0.0 );
	this.bone_geo.rotateX( Math.PI );
	this.bone_geo.scale( 0.6, 0.6, 0.6 );

	this.baseRing.ring.add( this.upperBoneMesh );
	this.platformRing.ring.add( this.lowerBoneMesh );

	this.lowerBoneChangeMatrix = new THREE.Matrix4();
	
};

Bone.prototype.update = function ( before_fix, cut_height, matrix, ap_rot, ap_trans, lat_rot, lat_trans ) {
	
	this.cutPlane.normal.x = 0;
	this.cutPlane.normal.z = 0;
	this.cutPlane.normal.y = 1;
	this.cutPlane.constant = -cut_height;

	var geom = sliceGeometry( this.bone_geo, this.cutPlane );

	this.upperBoneMesh.geometry = geom;

	this.cutPlane.normal.y = -1;
	this.cutPlane.constant = cut_height;

	geom = sliceGeometry( this.bone_geo, this.cutPlane );

	this.lowerBoneMesh.geometry = geom;

	if ( before_fix == true ) {
		// this.lowerBoneChangeMatrix.copy( matrix );

		var deformMat_trans_y = new THREE.Matrix4();
		var deformMat_trans_inv_y = new THREE.Matrix4();
		var deformMat_trans_x = new THREE.Matrix4();
		var deformMat_trans_z = new THREE.Matrix4();
		var deformMat_rot_z = new THREE.Matrix4();
		var deformMat_rot_x = new THREE.Matrix4();

		deformMat_trans_y.makeTranslation( 0.0, cut_height, 0.0 );
		deformMat_trans_inv_y.makeTranslation( 0.0, -cut_height, 0.0 );
		deformMat_trans_x.makeTranslation( ap_trans, 0.0, 0.0 );
		deformMat_trans_z.makeTranslation( 0.0, 0.0, lat_trans );
		deformMat_rot_z.makeRotationZ( ap_rot );
		deformMat_rot_x.makeRotationX( lat_rot );

		deformMat_trans_y.multiply( deformMat_trans_x );
		deformMat_trans_y.multiply( deformMat_trans_z );
		deformMat_trans_y.multiply( deformMat_rot_z );
		deformMat_trans_y.multiply( deformMat_rot_x );
		deformMat_trans_y.multiply( deformMat_trans_inv_y );

		this.lowerBoneChangeMatrix.getInverse( this.platformRing.ring.matrixWorld );
		this.lowerBoneChangeMatrix.multiply( deformMat_trans_y );

	} else {
		this.lowerBoneChangeMatrix.getInverse( this.platformRing.ring.matrixWorld );
	}

	this.lowerBoneMesh.matrix.copy( this.lowerBoneChangeMatrix );
	this.lowerBoneMesh.matrixAutoUpdate = false;

};

var Ring = function () {};

Ring.prototype.setUp = function ( strut_pieces ) {

	this.ring = strut_pieces.getObjectByName( "ring" ).clone();

	this.ring.traverse( function ( object ) {

    	if ( object instanceof THREE.Mesh )
    		object.material.color.setHex( 0x3c1e1d );

    });

};

Ring.prototype.update = function ( pos_orient ) {

	if ( pos_orient == undefined  ) {
		pos_orient = [ 0, 0, 0, 0, 0, 0 ];
	}

	this.ring.setRotationFromEuler( new THREE.Euler( pos_orient[3], pos_orient[4], pos_orient[5] ) );
	this.ring.position.set( pos_orient[0], pos_orient[1], pos_orient[2] );

	this.ring.updateMatrixWorld();

};

var Strut = function () {};

Strut.prototype.setUp = function ( strut_pieces, baseRing, platformRing ) {

	this.baseRing     = baseRing;
	this.platformRing = platformRing;

    this.t0 = strut_pieces.getObjectByName( "t0" ).clone();
    this.t2 = strut_pieces.getObjectByName( "t2" ).clone();
    this.t1 = this.t0.getObjectByName( "t1" );
    this.t3 = this.t2.getObjectByName( "t3" );

    this.platformRing.ring.add( this.t0 );
    this.baseRing.ring.add( this.t2 );

    this.t0.traverse( function ( object ) {

    	if ( object instanceof THREE.Mesh )
    		object.material.color.setHex( 0x676767 );

    });

    this.t2.traverse( function ( object ) {

    	if ( object instanceof THREE.Mesh )
    		object.material.color.setHex( 0x676767 );

    });

    this.t0.getObjectByName( "chip4" ).material.color.setHex( 0x3c1e1d );

};

Strut.prototype.update = function ( strut_connection ) {

	var RAD         = Math.PI / 180.0;
	var start_angle = 18.0 * RAD;
	var step_angle  = 13.8 * RAD;
	var radius      = 2.1;
	var alpha       = 0.0;

	if ( strut_connection[0] < 12 ) {
		alpha = start_angle + step_angle * strut_connection[0];
	} else {
		alpha = start_angle + step_angle * ( strut_connection[0] - 12 ) + Math.PI;
	}
	this.t2.position.set( Math.cos( alpha ) * radius, -0.45, Math.sin( alpha ) * radius );

	if ( strut_connection[1] < 12 ) {
		alpha = start_angle + step_angle * strut_connection[1];
	} else {
		alpha = start_angle + step_angle * ( strut_connection[1] - 12 ) + Math.PI;
	}
	this.t0.position.set( Math.cos( alpha ) * radius, 0.32, Math.sin( alpha ) * radius );

	this.t0.updateMatrixWorld();
	this.t2.updateMatrixWorld();

	var base_p = new THREE.Vector3();
	var invMat = new THREE.Matrix4();

	base_p.setFromMatrixPosition( this.t2.matrixWorld );

	invMat.getInverse( this.platformRing.ring.matrixWorld );
	base_p.applyMatrix4( invMat );

	var diff_p = this.t0.position.clone();
	diff_p.subVectors( base_p, diff_p );

	var t1_diff = diff_p.angleTo( new THREE.Vector3( 0.0, 1.0, 0.0 ) );
	diff_p.y = 0.0;
	var t0_diff = diff_p.angleTo( new THREE.Vector3( 0.0, 0.0, 1.0 ) );

	if ( diff_p.x < 0.0 ) {
		t0_diff = 2.0 * Math.PI - t0_diff;
	}

	this.t0.rotation.y = t0_diff;
	this.t1.rotation.x = t1_diff;

	var platform_p = new THREE.Vector3();

	platform_p.setFromMatrixPosition( this.t0.matrixWorld );

	invMat.getInverse( this.baseRing.ring.matrixWorld );
	platform_p.applyMatrix4( invMat );

	diff_p = this.t2.position.clone();
	diff_p.subVectors( diff_p, platform_p );

	var t3_diff = diff_p.angleTo( new THREE.Vector3( 0.0, 1.0, 0.0 ) );
	diff_p.y = 0.0;
	var t2_diff = diff_p.angleTo( new THREE.Vector3( 0.0, 0.0, 1.0 ) );

	if ( diff_p.x < 0.0 ) {
		t2_diff = 2.0 * Math.PI - t2_diff;
	}

	this.t2.rotation.y = t2_diff;
	this.t3.rotation.x = t3_diff;

};

var StewartPlatformBase = function ( objLoader, scene, scene_right ) {

	this.objLoader    = objLoader;
	this.scene        = scene;
	this.scene_right  = scene_right;

	// this.strut_pieces = [];
	// this.ring_pieces  = [];
	// this.bone_pieces  = [];	

	this.struts       = [];
	this.struts_right = [];

	this.is_scene_setup = false;
	this.requestUpdateState = false;

};

// param = {
// 	platform_pos_orient: [ x, y, z, alpha, beta, gammar ],
// 	strut_connection: [ [ B, P ], [ B, P ], [ B, P ], [ B, P ], [ B, P ], [ B, P ] ]
// }
StewartPlatformBase.prototype.updateState = function ( param ) {

	if ( this.is_scene_setup == false ) {
		this.param = param;
		this.requestUpdateState = true;

		return;
	}

	// correct platform position and orientation.
	// var _temp = param.platform_pos_orient[1];
	// param.platform_pos_orient[1] = -param.platform_pos_orient[2];
	// param.platform_pos_orient[2] = _temp;

	var _temp = param.platform_pos_orient_right[1];
	param.platform_pos_orient_right[1] = -param.platform_pos_orient_right[2];
	param.platform_pos_orient_right[2] = _temp;

	var _scale = 0.1;
	param.platform_pos_orient_right[0] *= _scale;
	param.platform_pos_orient_right[1] *= _scale;
	param.platform_pos_orient_right[2] *= _scale;

	console.log(param.platform_pos_orient_right);

	// after correction
	this.baseRing.update();
	this.platformRing.update( param.platform_pos_orient );

	var i = this.struts.length;
	while(i--) {
		this.struts[i].update( param.strut_connection[ i ] );
	}

	this.bone.update( false, -2.0 );

	// before correction
	this.baseRing_right.update();
	this.platformRing_right.update( param.platform_pos_orient_right );

	var i = this.struts_right.length;
	while(i--) {
		this.struts_right[i].update( param.strut_connection[ i ] );
	}

	// this.bone_right.update( true, -2.0, this.bone.lowerBoneChangeMatrix );
	this.bone_right.update( true, -2.0, null, param.bone_rot_trans[0], param.bone_rot_trans[1], param.bone_rot_trans[2], param.bone_rot_trans[3] );

};

StewartPlatformBase.prototype.loadResourceAndSetup = function () {
	
	this.is_scene_setup = false;
	
	var self = this;

	var model_loaded_count = 0;

	(function loadStrut() {
		var objectLoader = new THREE.ObjectLoader();
		objectLoader.load( "/stewartplatform/asset/strut.json", function ( object ) {

            self.strut_pieces = object;

            onLoadResourceComplete();

        }, onProgress, onError );

	})();

	(function loadRing() {
		var objectLoader = new THREE.ObjectLoader();
        objectLoader.load( "/stewartplatform/asset/ring.json", function ( object ) {

            self.ring_pieces = object;

            onLoadResourceComplete();

        }, onProgress, onError );

    })();

    (function loadBone() {

        self.objLoader.load( "/stewartplatform/asset/bone4.obj", function ( object ) {
            
            var children = [];
           
           	object.traverse( function ( child ) {
                if ( child instanceof THREE.Mesh ) {
                    child.geometry.computeBoundingBox();
            		self.bone_pieces = child;
                }
            });


            onLoadResourceComplete();

        }, onProgress, onError );

    })();    

    function setupScene() {

    	var lights = [];
    	var ambientLight = new THREE.AmbientLight( 0xeeeeee );
	  	
	  	lights[ 0 ] = new THREE.PointLight( 0xffffff, 1, 0 );
	  	lights[ 1 ] = new THREE.PointLight( 0xffffff, 1, 0 );
		lights[ 2 ] = new THREE.PointLight( 0xffffff, 1, 0 );
		lights[ 0 ].position.set( 0, 200, 0 );
		lights[ 1 ].position.set( 100, 200, 100 );
		lights[ 2 ].position.set( - 100, - 200, - 100 );
      	
      	self.scene.add( ambientLight );
		self.scene.add( lights[ 0 ] );
		self.scene.add( lights[ 1 ] );
		self.scene.add( lights[ 2 ] );

		self.baseRing = new Ring();
		self.baseRing.setUp( self.ring_pieces );
		self.scene.add( self.baseRing.ring );

		self.platformRing = new Ring();
		self.platformRing.setUp( self.ring_pieces );
		self.scene.add( self.platformRing.ring);

		self.bone = new Bone();
		self.bone.setUp( self.bone_pieces, self.baseRing, self.platformRing );

		for ( var i = 0; i < 6; i++ ) {
			var strut = new Strut();
			strut.setUp( self.strut_pieces, self.baseRing, self.platformRing );
      		self.struts.push( strut );
		}

		// setting up right scene.

      	self.scene_right.add( ambientLight.clone() );
		self.scene_right.add( lights[ 0 ].clone() );
		self.scene_right.add( lights[ 1 ].clone() );
		self.scene_right.add( lights[ 2 ].clone() );

		self.baseRing_right = new Ring();
		self.baseRing_right.setUp( self.ring_pieces );
		self.scene_right.add( self.baseRing_right.ring );

		self.platformRing_right = new Ring();
		self.platformRing_right.setUp( self.ring_pieces );
		self.scene_right.add( self.platformRing_right.ring);

		self.bone_right = new Bone();
		self.bone_right.setUp( self.bone_pieces, self.baseRing_right, self.platformRing_right );

		for ( var i = 0; i < 6; i++ ) {
			var strut = new Strut();
			strut.setUp( self.strut_pieces, self.baseRing_right, self.platformRing_right );
      		self.struts_right.push( strut );
		}

		self.is_scene_setup = true;
		if ( self.requestUpdateState == true ) {
			self.requestUpdateState = false;
			self.updateState( self.param );
		} 
    };

    function onLoadResourceComplete() {
    	model_loaded_count++;
        if ( model_loaded_count == 3 ) {
            setupScene();
        }
    };

	function onProgress( xhr ) {
		if ( xhr.lengthComputable ) {
          var percentComplete = xhr.loaded / xhr.total * 100;
          console.log( Math.round(percentComplete, 2) + '% downloaded' );
        }
	};

	function onError() {
		console.log( "resource load error." );
	};
};

StewartPlatformBase.prototype.render = function () {

};